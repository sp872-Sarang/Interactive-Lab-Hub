# bus > 2022-12-15 5:53pm
https://universe.roboflow.com/object-detection/bus-xjs5k

Provided by a Roboflow user
License: CC BY 4.0

